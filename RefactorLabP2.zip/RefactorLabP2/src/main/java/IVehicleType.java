public interface IVehicleType {
    public int perHeadFare();
    public boolean canTakeTrip();
}
