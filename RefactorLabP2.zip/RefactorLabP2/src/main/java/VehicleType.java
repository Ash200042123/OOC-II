public enum VehicleType {
    SEDAN, MOTOR_BIKE, SEVEN_SEATER
}
