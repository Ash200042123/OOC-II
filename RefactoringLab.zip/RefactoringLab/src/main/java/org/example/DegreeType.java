package org.example;

public enum DegreeType {
    RegularThesis, RegularNonThesis, Executive
}