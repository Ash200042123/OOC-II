package Task4;

import Task3.Calculator;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class AbstractionTest {
    @Test
    public void checkAbstract(){
        Calculator calculator=new Calculator();

    }
}
