package org.example;

import Task2.KidsBook;
import Task2.NewBook;
import Task2.RegularBook;
import Task2.RentService;

public class Main {
    public static void main(String[] args) {

    }
}