package Task1B;

public class Mail {
    
}
