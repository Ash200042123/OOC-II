package Task1A;

public interface Power {
    void plugIn(Computer c);
 void shutDown(Computer c);
 void hibernate(Computer c);
}
