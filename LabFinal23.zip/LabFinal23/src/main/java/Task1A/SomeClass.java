package Task1A;

public class SomeClass implements Power,CheckPrice{
    @Override
    public void hasSamePrice(Computer c1, Computer c2) {

    }

    @Override
    public void plugIn(Computer c) {

    }

    @Override
    public void shutDown(Computer c) {

    }

    @Override
    public void hibernate(Computer c) {

    }
}
