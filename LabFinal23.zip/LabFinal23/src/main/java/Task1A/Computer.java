package Task1A;

public class Computer {
}
