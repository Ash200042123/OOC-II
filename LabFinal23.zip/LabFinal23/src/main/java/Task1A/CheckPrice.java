package Task1A;

public interface CheckPrice {

    void hasSamePrice(Computer c1, Computer c2);
}
